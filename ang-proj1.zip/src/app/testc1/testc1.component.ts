import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testc1',
  templateUrl: './testc1.component.html',
  styleUrls: ['./testc1.component.css']
})
export class Testc1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
